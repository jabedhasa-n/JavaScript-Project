let personAge =prompt("Please input you age");

if (personAge>=20 && personAge<=35){
   console.log("User can be allowed");
}
else{
    console.log("User can be not allowed");
 };